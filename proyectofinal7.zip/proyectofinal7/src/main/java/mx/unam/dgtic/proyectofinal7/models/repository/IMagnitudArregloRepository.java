package mx.unam.dgtic.proyectofinal7.models.repository;

import org.springframework.data.repository.CrudRepository;

import mx.unam.dgtic.proyectofinal7.models.entity.MagnitudArreglo;

public interface IMagnitudArregloRepository extends CrudRepository<MagnitudArreglo, Integer> {

}
