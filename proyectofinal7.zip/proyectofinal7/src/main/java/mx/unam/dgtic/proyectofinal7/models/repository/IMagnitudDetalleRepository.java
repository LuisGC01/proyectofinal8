package mx.unam.dgtic.proyectofinal7.models.repository;

import org.springframework.data.repository.CrudRepository;

import mx.unam.dgtic.proyectofinal7.models.entity.MagnitudDetalle;

public interface IMagnitudDetalleRepository extends CrudRepository<MagnitudDetalle, Integer> {
	



}
